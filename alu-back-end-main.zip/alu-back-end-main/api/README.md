This project is about learning API and how it is used to interact with servers.
